
package ZwothePoe1;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;
    private String status;

    private static int totalMessagesSent = 0;
    private static int totalMessagesEntered = 0;

    private static final List<Message> storedMessages =
            new ArrayList<>();

    // CONSTRUCTOR
    public Message(
            String recipient,
            String messageText,
            int messageNumber) {

        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
        this.messageHash = createMessageHash();
        this.status = "Pending";
    }

    // GENERATE A RANDOM 10-DIGIT MESSAGE ID
    private String generateMessageID() {

        Random random = new Random();

        long number = 1_000_000_000L
                + (long) (random.nextDouble() * 9_000_000_000L);

        return String.valueOf(number);
    }

    // CHECK MESSAGE ID
    public boolean checkMessageID() {

        return messageID != null
                && messageID.matches("[0-9]{10}");
    }

    // CHECK RECIPIENT CELLPHONE NUMBER
    public boolean checkRecipientCell() {

        if (recipient == null) {
            return false;
        }

        // International format and the local format
        // supplied in the POE example data.
        return recipient.matches("\\+27[6-8][0-9]{8}")
                || recipient.matches("0[6-8][0-9]{8,9}");
    }

    // CREATE MESSAGE HASH
    public String createMessageHash() {

        String firstTwoDigits = messageID.substring(0, 2);
        String trimmedMessage = messageText.trim();

        if (trimmedMessage.isEmpty()) {
            return firstTwoDigits + ":" + messageNumber + ":";
        }

        String[] words = trimmedMessage.split("\\s+");

        String firstWord = words[0].replaceAll(
                "[^\\p{L}\\p{N}]", "");

        String lastWord = words[words.length - 1].replaceAll(
                "[^\\p{L}\\p{N}]", "");

        return (firstTwoDigits + ":"
                + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    // START QUICKCHAT
    public static void startQuickChat(Scanner input) {

        System.out.println("\nWelcome to QuickChat.");

        int numberOfMessages = readNonNegativeInteger(
                input,
                "How many messages would you like to enter? ");

        totalMessagesEntered = 0;

        while (true) {

            System.out.println("\nQUICKCHAT MENU");
            System.out.println("1. Send Messages");
            System.out.println(
                    "2. Show recently sent messages");
            System.out.println("3. Quit");

            System.out.print("Choose an option: ");
            String choice = input.nextLine().trim();

            switch (choice) {

                case "1":

                    if (totalMessagesEntered >= numberOfMessages) {

                        System.out.println(
                                "You have entered the maximum "
                                + "number of messages.");

                    } else {

                        sendMessages(input, numberOfMessages);
                    }

                    break;

                case "2":

                    System.out.println("Coming Soon.");
                    break;

                case "3":

                    System.out.println(
                            "Total messages successfully sent: "
                            + totalMessagesSent);

                    System.out.println(
                            "Thank you for using QuickChat.");

                    return;

                default:

                    System.out.println(
                            "Invalid option. Please choose 1, 2, or 3.");
            }
        }
    }

    // READ A VALID WHOLE NUMBER
    private static int readNonNegativeInteger(
            Scanner input,
            String prompt) {

        while (true) {

            System.out.print(prompt);
            String value = input.nextLine().trim();

            try {

                int number = Integer.parseInt(value);

                if (number >= 0) {
                    return number;
                }

                System.out.println(
                        "Please enter zero or a positive number.");

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a valid whole number.");
            }
        }
    }

    // SEND MESSAGES
    private static void sendMessages(
            Scanner input,
            int maximumMessages) {

        while (totalMessagesEntered < maximumMessages) {

            int currentMessageNumber = totalMessagesEntered;

            System.out.println(
                    "\nMessage " + (currentMessageNumber + 1)
                    + " of " + maximumMessages);

            String recipient;

            // VALIDATE RECIPIENT
            while (true) {

                System.out.print(
                        "Enter recipient cellphone number: ");

                recipient = input.nextLine().trim();

                Message recipientCheck =
                        new Message(recipient, "Test message", 0);

                if (recipientCheck.checkRecipientCell()) {

                    System.out.println(
                            "Cell phone number successfully captured.");

                    break;

                } else {

                    System.out.println(
                            "Cell phone number is incorrectly formatted "
                            + "or does not contain a valid South African "
                            + "number. Please correct the number "
                            + "and try again.");
                }
            }

            String text;

            // VALIDATE MESSAGE LENGTH
            while (true) {

                System.out.print("Enter your message: ");
                text = input.nextLine();

                if (text.length() <= 250) {

                    System.out.println("Message ready to send.");
                    break;

                } else {

                    System.out.println(
                            "Message exceeds 250 characters by "
                            + (text.length() - 250)
                            + "; please reduce the size.");
                }
            }

            Message newMessage = new Message(
                    recipient,
                    text,
                    currentMessageNumber);

            System.out.println(
                    "Message ID generated: " + newMessage.messageID);

            System.out.println(
                    "Message Hash: " + newMessage.messageHash);

            // MESSAGE OPTIONS
            System.out.println("\n1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. Store Message");

            String result = newMessage.SentMessage(input);

            System.out.println(result);

            if (newMessage.status.equals("Sent")) {

                totalMessagesSent++;

                System.out.println("\nMessage details:");
                System.out.println(
                        "Message ID: " + newMessage.messageID);
                System.out.println(
                        "Message Hash: " + newMessage.messageHash);
                System.out.println(
                        "Recipient: " + newMessage.recipient);
                System.out.println(
                        "Message: " + newMessage.messageText);

            } else if (newMessage.status.equals("Stored")) {

                storedMessages.add(newMessage);
                newMessage.storeMessage();
            }

            // Count sent, disregarded and stored messages
            // against the number the user requested.
            totalMessagesEntered++;

            if (totalMessagesEntered >= maximumMessages) {

                System.out.println(
                        "\nYou have entered all "
                        + maximumMessages + " requested messages.");

                break;
            }

            System.out.print(
                    "\nEnter the next message? (yes/no): ");

            String answer = input.nextLine().trim();

            if (answer.equalsIgnoreCase("no")) {
                break;
            }
        }
    }

    // SEND, DISREGARD OR STORE A MESSAGE
    public String SentMessage(Scanner input) {

        while (true) {

            System.out.print("Choose an option: ");
            String choice = input.nextLine().trim();

            switch (choice) {

                case "1":

                    status = "Sent";
                    return "Message successfully sent";

                case "2":

                    status = "Disregarded";
                    return "Press 0 to delete the message";

                case "3":

                    status = "Stored";
                    return "Message successfully stored";

                default:

                    System.out.println(
                            "Invalid choice. Enter 1, 2, or 3.");
            }
        }
    }

    // PRINT MESSAGE DETAILS
    public String printMessages() {

        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + messageText
                + "\nStatus: " + status;
    }

    // RETURN TOTAL MESSAGES SENT
    public int returnTotalMessages() {

        return totalMessagesSent;
    }

    // METHOD NAME AS SPELLED IN THE POE
    public int returnTotalMessagess() {

        return returnTotalMessages();
    }

    // STORE MESSAGES IN A JSON FILE
    public void storeMessage() {

        try (FileWriter writer =
                     new FileWriter("messages.json")) {

            writer.write("[\n");

            for (int i = 0; i < storedMessages.size(); i++) {

                Message stored = storedMessages.get(i);

                writer.write("  {\n");

                writer.write(
                        "    \"messageID\": \""
                        + escapeJson(stored.messageID) + "\",\n");

                writer.write(
                        "    \"messageNumber\": "
                        + stored.messageNumber + ",\n");

                writer.write(
                        "    \"recipient\": \""
                        + escapeJson(stored.recipient) + "\",\n");

                writer.write(
                        "    \"message\": \""
                        + escapeJson(stored.messageText) + "\",\n");

                writer.write(
                        "    \"messageHash\": \""
                        + escapeJson(stored.messageHash) + "\",\n");

                writer.write(
                        "    \"status\": \""
                        + escapeJson(stored.status) + "\"\n");

                writer.write("  }");

                if (i < storedMessages.size() - 1) {
                    writer.write(",");
                }

                writer.write("\n");
            }

            writer.write("]\n");

            System.out.println(
                    "Stored messages saved to messages.json.");

        } catch (IOException e) {

            System.out.println(
                    "Error saving messages: " + e.getMessage());
        }
    }

    // ESCAPE SPECIAL CHARACTERS FOR JSON
    private String escapeJson(String value) {

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
