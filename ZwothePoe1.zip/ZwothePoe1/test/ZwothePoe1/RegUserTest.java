package ZwothePoe1;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class RegUserTest {

    private RegUser user;

    public RegUserTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {

        user = new RegUser();

        user.name = "Zwothe";
        user.lastName = "Nedzi";
        user.userName = "Z_01";
        user.passWord = "Password1!";
        user.cellNumber = "+27838968976";
    }

    @After
    public void tearDown() {
    }

    // ==============================
    // REGUSER TESTS
    // ==============================

    @Test
    public void testUserNameIsCorrectlyFormatted() {

        assertTrue(LogUser.checkUserName("Z_01"));
    }

    @Test
    public void testUserNameIsIncorrectlyFormatted() {

        assertFalse(LogUser.checkUserName("Zwothe"));
    }

    @Test
    public void testPasswordComplexityIsCorrect() {

        assertTrue(LogUser.checkPasswordComplexity("Password1!"));
    }

    @Test
    public void testPasswordComplexityIsIncorrect() {

        assertFalse(LogUser.checkPasswordComplexity("password"));
    }

    @Test
    public void testCellPhoneNumberIsCorrectlyFormatted() {

        assertTrue(LogUser.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testCellPhoneNumberIsIncorrectlyFormatted() {

        assertFalse(LogUser.checkCellPhoneNumber("0838968976"));
    }

    @Test
    public void testSignupUserSuccessful() {

        String result = LogUser.signupUser(user);

        assertEquals("Signup was successful!", result);
    }

    @Test
    public void testSignupUserWithIncorrectUsername() {

        user.userName = "Zwothe";

        String result = LogUser.signupUser(user);

        assertEquals(
                "Username is not correctly formatted; "
                + "please ensure that your username contains "
                + "an underscore and is no more than five "
                + "characters in length.",
                result
        );
    }

    @Test
    public void testSignupUserWithIncorrectPassword() {

        user.passWord = "password";

        String result = LogUser.signupUser(user);

        assertEquals(
                "Password is not correctly formatted; "
                + "please ensure that the password contains "
                + "at least eight characters, a capital letter, "
                + "a number, and a special character.",
                result
        );
    }

    @Test
    public void testSignupUserWithIncorrectCellNumber() {

        user.cellNumber = "0838968976";

        String result = LogUser.signupUser(user);

        assertEquals(
                "Cell number is incorrectly formatted or does "
                + "not contain an international code; "
                + "please correct the number and try again.",
                result
        );
    }

    // ==============================
    // LOGUSER TESTS
    // ==============================

    @Test
    public void testSigninStatusSuccessful() {

        String result = LogUser.returnSigninStatus(user, true);

        assertEquals(
                "Welcome Zwothe, Nedzi it is great to see you again.",
                result
        );
    }

    @Test
    public void testSigninStatusUnsuccessful() {

        String result = LogUser.returnSigninStatus(user, false);

        assertEquals(
                "Username or password incorrect, please try again.",
                result
        );
    }

    // ==============================
    // INTEGRATION TEST
    // ==============================

    @Test
    public void testSignupAndSigninIntegration() {

        // Test that the registered user is successfully captured
        String signupResult = LogUser.signupUser(user);

        assertEquals(
                "Signup was successful!",
                signupResult
        );

        // Simulate entering the registered username and password
        String loginInput =
                user.userName + "\n"
                + user.passWord + "\n";

        InputStream originalInput = System.in;

        try {

            System.setIn(
                    new ByteArrayInputStream(
                            loginInput.getBytes()
                    )
            );

            Scanner input = new Scanner(System.in);

            boolean signinResult =
                    LogUser.signinUser(user, input);

            assertTrue(signinResult);

            input.close();

        } finally {

            System.setIn(originalInput);
        }
    }
}